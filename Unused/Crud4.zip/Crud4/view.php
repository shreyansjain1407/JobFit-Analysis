
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Pure CSS Table Highlight (vertical & horizontal)</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>
  <div class="container">

</div>
  
  
</body>
</html>

<?php
$connect_db = mysqli_connect("localhost","root","") or die("Cannot connect to server");
mysqli_select_db($connect_db,"user") or die("Cannot connect to the database");

$query = mysqli_query($connect_db,"select * from person  order by id desc");
?>
<table border="1">
<tr>
    <th>Name</th>
    <th>Age</th>
	<th>F1</th>
<th>F2</th>
<th>F3</th>
<th>F4</th>
<th>F5</th>
<th>Feedback</th>
    <th>Action</th>
</tr>
<?php

if(mysqli_num_rows($query)>0){
 
		
    while($row= mysqli_fetch_array($query)){ ?>
    <tr>
        <td><?=$row['name']?></td>
        <td><?=$row['age']?></td>
		<td><?=$row['N1']?></td>
		<td><?=$row['N2']?></td>
		<td><?=$row['N3']?></td>
		<td><?=$row['N4']?></td>
		<td><?=$row['N5']?></td>
		<td><?=$row['Msg']?></td>
		
        <td><a href="update.php?id=<?=$row['id']?>">[Edit]</a>&nbsp;<a href="delete.php?id=<?=$row['id']?>">[Delete]</a></td>
    </tr>
	
<?php        
        
    }
        
}
else{
    
    echo "no record";
}

?>
<tr><td colspan="3"><a href="index.php" >[Add new record]</a>
</td></tr>
</table>
