<?php

$connect_db = mysqli_connect("localhost","root","") or die("Cannot connect to server");
mysqli_select_db($connect_db,"user") or die("Cannot connect to the database");


if (isset($_POST['name']))
{
    $mname = $_POST['name'];
}

	   
if (isset($_POST['age']))
{
    $age = $_POST['age'];
}

if (isset($_POST['description']))
{
    $msg = $_POST['description'];
}

   $phpVar =  $_COOKIE['myJavascriptVar'];

//echo <script>document.cookie = '"myJavascriptVar =0"';</script>"

  $str = $phpVar;
    $parts = explode("-", $str);
    $one = $parts[0];
    $two = $parts[1];
 $the = $parts[2];
    $fo4 = $parts[3];
 $fiv = $parts[4];


 echo "<script>alert('$one' + '$fiv' + '$phpVar' );</script>";
   
//$name= ($_POST['studentname']);
//$age = ($_POST['studentage']);
//echo ($_POST['name'] + $_POST['age']);
mysqli_query($connect_db,"insert into person set name='$mname', age='$age', n1='$one', n2='$two', n3='$the', n4='$fo4', n5='$fiv',msg='$msg'");
//mysqli_query($connect_db,"insert into person set name='Kushw', age='112'");
echo "<script>alert('Record successfuly saved.');window.location.href='view.php';</script>";
    
?>

