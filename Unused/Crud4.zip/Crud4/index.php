<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V5</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" href="cssOpt/style.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


	<link rel="stylesheet" href="cssSC/style.css">

</head>

<body>



<div class="limiter">

		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			
				<form class="login100-form validate-form flex-sb flex-w" action='add.php' method="post">
					<span class="login100-form-title p-b-53">
						Welcome  <?php echo $_GET["name1"]  ?> !!!
					</span>


					<div class="rb-box">

						<!-- Radio Button Module -->
						<p>1. On a scale of 1 to 5 how  you?</p>
						<div id="rb-1" class="rb">
							<div class="rb-tab rb-tab-active" data-value="1">
								<div class="rb-spot">
									<span class="rb-txt">1</span>
								</div>
							</div><div class="rb-tab" data-value="2">
							<div class="rb-spot">
								<span class="rb-txt">2</span>
							</div>
						</div><div class="rb-tab" data-value="3">
							<div class="rb-spot">
								<span class="rb-txt">3</span>
							</div>
						</div><div class="rb-tab" data-value="4">
							<div class="rb-spot">
								<span class="rb-txt">4</span>
							</div>
						</div><div class="rb-tab" data-value="5">
							<div class="rb-spot">
								<span class="rb-txt">5</span>
							</div>
						</div>
						</div>

						<!-- Radio Button Module -->
						<p>2. On a scale of 1 to 5 how e universe?</p>
						<div id="rb-2" class="rb">
							<div class="rb-tab" data-value="1">
								<div class="rb-spot">
									<span class="rb-txt">1</span>
								</div>
							</div><div class="rb-tab rb-tab-active" data-value="2">
							<div class="rb-spot">
								<span class="rb-txt">2</span>
							</div>
						</div><div class="rb-tab" data-value="3">
							<div class="rb-spot">
								<span class="rb-txt">3</span>
							</div>
						</div><div class="rb-tab" data-value="4">
							<div class="rb-spot">
								<span class="rb-txt">4</span>
							</div>
						</div><div class="rb-tab" data-value="5">
							<div class="rb-spot">
								<span class="rb-txt">5</span>
							</div>
						</div>
						</div>

						<!-- Radio Button Module -->
						<p>3. On a scale of 1 to 5 how much  stalactites?</p>
						<div id="rb-3" class="rb">
							<div class="rb-tab" data-value="1">
								<div class="rb-spot">
									<span class="rb-txt">1</span>
								</div>
							</div><div class="rb-tab" data-value="2">
							<div class="rb-spot">
								<span class="rb-txt">2</span>
							</div>
						</div><div class="rb-tab rb-tab-active" data-value="3">
							<div class="rb-spot">
								<span class="rb-txt">3</span>
							</div>
						</div><div class="rb-tab" data-value="4">
							<div class="rb-spot">
								<span class="rb-txt">4</span>
							</div>
						</div><div class="rb-tab" data-value="5">
							<div class="rb-spot">
								<span class="rb-txt">5</span>
							</div>
						</div>
						</div>

						<!-- Radio Button Module -->
						<p>4. On a scale of 1 to 5 what is your  alphabet?</p>
						<div id="rb-4" class="rb">
							<div class="rb-tab" data-value="1">
								<div class="rb-spot">
									<span class="rb-txt">1</span>
								</div>
							</div><div class="rb-tab" data-value="2">
							<div class="rb-spot">
								<span class="rb-txt">2</span>
							</div>
						</div><div class="rb-tab" data-value="3">
							<div class="rb-spot">
								<span class="rb-txt">3</span>
							</div>
						</div><div class="rb-tab rb-tab-active" data-value="4">
							<div class="rb-spot">
								<span class="rb-txt">4</span>
							</div>
						</div><div class="rb-tab" data-value="5">
							<div class="rb-spot">
								<span class="rb-txt">5</span>
							</div>
						</div>
						</div>

						<!-- Radio Button Module -->
						<p>5. On a scale of one to shrimp, how  you?</p>
						<div id="rb-5" class="rb">
							<div class="rb-tab" data-value="4">
								<div class="rb-spot">
									<span class="rb-txt">4</span>
								</div>
							</div><div class="rb-tab" data-value="2">
							<div class="rb-spot">
								<span class="rb-txt">2</span>
							</div>
						</div><div class="rb-tab" data-value="5">
							<div class="rb-spot">
								<span class="rb-txt">5</span>
							</div>
						</div><div class="rb-tab" data-value="1">
							<div class="rb-spot">
								<span class="rb-txt">1</span>
							</div>
						</div><div class="rb-tab rb-tab-active" data-value="3">
							<div class="rb-spot">
								<span class="rb-txt">3</span>
							</div>
						</div>
						</div>

										
					<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>

					 <script>
		//Global:
var survey = []; //Bidimensional array: [ [1,3], [2,4] ]
var msg;
//Switcher function:
$(".rb-tab").click(function(){
  //Spot switcher:
  $(this).parent().find(".rb-tab").removeClass("rb-tab-active");
  $(this).addClass("rb-tab-active");
});

//Save data:
$(".trigger").click(function(){
  //Empty array:
  survey = [];
  //Push data:
  for (i=1; i<=$(".rb").length; i++) {
    var rb = "rb" + i;
    var rbValue = parseInt($("#rb-"+i).find(".rb-tab-active").attr("data-value"));
    //Bidimensional array push:
    survey.push([i, rbValue]); //Bidimensional array: [ [1,3], [2,4] ]
  };
  //Debug:
  debug();
alert(msg);
  

});

//Debug:
function debug(){
  var debug = "";
  for (i=0; i<survey.length; i++) {
    debug += survey[i][1] + '-' ;
  };
  alert(debug);

  //window.location.href="add.php?msg='ravi'" 
document.cookie = "myJavascriptVar =" + debug ;
};
	
	
	
	</script>

								


		

					<div class="p-t-31 p-b-9">
						<span class="txt1">
							Username
						</span>
					</div>


					<div class="wrap-input100 validate-input" data-validate = "Username is required">
						<input class="input100" type="text" name="name" >
						<span class="focus-input100"></span>
					</div>

					<div class="p-t-13 p-b-9">
						<span class="txt1">
							Password
						</span>

						<a href="#" class="txt2 bo1 m-l-5">
							Forgot?
						</a>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="text" name="age">
						<span class="focus-input100"></span>
					</div>
					
					
				<br>
		<div class="wrap-input100 validate-input" data-validate = "Feedback">			
          <textarea class="input100" rows = "5"  name = "description"> </textarea><br>
		 </div>
					<div class="container-login100-form-btn m-t-17"  align: center>
						<button class="login100-form-btn" align: center>
							Sign In
						</button>
					</div>
</div>

                  </form>


			</div>
		</div>




<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/bootstrap/js/popper.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="vendor/daterangepicker/moment.min.js"></script>
<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>

</body>

</html>


